import logging
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters
import openai

# مقداردهی کلیدها
TELEGRAM_TOKEN = "7985943305:AAFtN5o-lSA_JBPcghgL8y4JL4qAtGGQ0sM"
LIARA_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySUQiOiI2ODg0ZWIwM2QyYmEwZGFhYWUyODk1MjMiLCJ0eXBlIjoiYXV0aCIsImlhdCI6MTc1MzU2ODkwMn0.joR3U8IVF1wlnRmLXgzdRbOoe_QGMko8wDcuVMsztsA"

client = openai.OpenAI(
    base_url="https://ai.liara.ir/api/v1/688553e109531249eace1f92",
    api_key=LIARA_API_KEY,
)

logging.basicConfig(level=logging.INFO)

buttons = [
    ["🛋 مشاهده محصولات", "💬 مشاوره دکوراسیون"],
    ["🖼 نمونه‌کارها", "📞 تماس با ما"]
]

keyboard = ReplyKeyboardMarkup(buttons, resize_keyboard=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 خوش آمدید به ربات آرادچوب", reply_markup=keyboard)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text

    if text == "🛋 مشاهده محصولات":
        await update.message.reply_text("در حال حاضر لیست محصولات در حال به‌روزرسانی است.")
    elif text == "🖼 نمونه‌کارها":
        await update.message.reply_text("نمونه‌کارها به‌زودی افزوده می‌شوند.")
    elif text == "📞 تماس با ما":
        await update.message.reply_text("📞 شماره تماس: 0912-XXXXXXX
👷 تکنسین نصب: 0935-XXXXXXX")
    elif text == "💬 مشاوره دکوراسیون":
        await update.message.reply_text("سؤال خود را در مورد دکوراسیون داخلی بپرسید تا آرا به شما پاسخ دهد.")
    else:
        response = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=[
                {"role": "system", "content": "تو یک مشاور حرفه‌ای دکوراسیون داخلی به نام آرا هستی."},
                {"role": "user", "content": text}
            ]
        )
        await update.message.reply_text(response.choices[0].message.content)

if __name__ == "__main__":
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()
